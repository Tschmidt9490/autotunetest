// AutotunePID.h
#ifndef AutotunePID_h
#define AutotunePID_h

#include "Arduino.h"

class AutotunePID {
public:
    // Opdaterer konstruktøren til at tillade en valgfri temperatur-læsningsfunktion ved initialisering
    AutotunePID(int heaterPin, float (*tempReadFunc)() = nullptr);
    void begin(double setpoint, int desiredOscillations);
    void update();
    bool isRunning();
    void getPIDParameters(float &Kp, float &Ki, float &Kd);
    // Metode til at sætte en ekstern temperatur-læsningsfunktion efter objektet er blevet initialiseret
    void setTemperatureReadFunction(float (*tempReadFunc)());

private:
    int _heaterPin;
    // Fjerner _tempSensorPin, da temperatur-læsningen kan ske gennem den eksterne funktion
    unsigned long _lastSwitchTime;
    const long _switchDelay = 5000;
    bool _heaterState;
    float _maxTemp, _minTemp, _lastTemp;
    unsigned long _lastPeakTime, _periodSum;
    int _peakCount;
    bool _lookingForMax;
    int _desiredOscillations;
    bool _autotuneStarted;
    float _Kp, _Ki, _Kd;
    float (*_tempReadFunc)() = nullptr; // Pointer til den eksterne temperatur-læsningsfunktion

    void toggleHeater();
    void recordPeak(float currentTemp);
    void calculatePIDParams();
    double readTemperature(); // Gør denne metode privat
};

#endif
