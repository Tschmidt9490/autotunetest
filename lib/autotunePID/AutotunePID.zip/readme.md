# AutotunePID Library

The AutotunePID is an Arduino library designed to facilitate PID autotuning for temperature-controlled systems. By applying the Ziegler-Nichols method for autotuning, users can easily find optimal PID parameters for their system, ensuring precise and stable temperature control.

## Installation

1. Download the latest version of the AutotunePID library.
2. Open the Arduino IDE.
3. Navigate to Sketch > Include Library > Add .ZIP Library... and select the downloaded file.
4. The library is now installed and ready for use.

## Usage

To use the AutotunePID library in your project, include it at the top of your sketch:

```cpp
#include <AutotunePID.h>
```

Next, create an instance of the `AutotunePID` class. You can specify your own temperature reading function at creation or use the built-in method (if available):

```cpp
// Define the heater pin number
#define HEATER_PIN 5

// Custom function to read temperature
double readTemperature() {
    // Your code to read the temperature here
    return analogRead(A0) * (5.0 / 1023.0) * 100; // Example
}

// Create an AutotunePID instance with a custom temperature reading function
AutotunePID autotuner(HEATER_PIN, readTemperature);
```

To start the autotuning process, specify a setpoint and the desired number of oscillations:

```cpp
autotuner.begin(100.0, 5); // Setpoint at 100 degrees, 5 oscillations
```

Continuously update the autotuning loop in your `loop()` function:

```cpp
void loop() {
    autotuner.update();

    if (!autotuner.isRunning()) {
        // Autotuning is complete, retrieve and apply PID parameters
        double Kp, Ki, Kd;
        autotuner.getPIDParameters(Kp, Ki, Kd);
        
        // Apply PID parameters as needed
        Serial.print("Kp: "); Serial.println(Kp);
        Serial.print("Ki: "); Serial.println(Ki);
        Serial.print("Kd: "); Serial.println(Kd);
    }
}
```

## Example

Refer to the `examples` folder in this library to find complete examples of how to integrate AutotunePID into your project.

## Contributing

Contributions to the library are welcome. Please submit pull requests or create issues via GitHub to suggest improvements or report bugs.

## License

This library is released under the [MIT License](LICENSE).

