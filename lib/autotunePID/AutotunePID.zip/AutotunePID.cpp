// AutotunePID.cpp
#include "AutotunePID.h"


AutotunePID::AutotunePID(const int heaterPin, float (*tempReadFunc)()) : _heaterPin(heaterPin), _tempReadFunc(tempReadFunc) {
    //pinMode(_heaterPin, OUTPUT);
    
    /*
    ledcSetup(3, 4, 16);
    ledcAttachPin(heaterPin, 3);
    */
}

void AutotunePID::begin(double setpoint, int desiredOscillations) {
    _lastSwitchTime = millis();
    _maxTemp = _minTemp = _lastTemp = setpoint;
    _peakCount = 0;
    _periodSum = 0;
    _desiredOscillations = desiredOscillations;
    _autotuneStarted = true;
    _heaterState = false;
}

void AutotunePID::update() {
    if (!_autotuneStarted) return;
  
    float currentTemp = readTemperature();
    toggleHeater();
    recordPeak(currentTemp);

    if (_peakCount / 2 >= _desiredOscillations) {
        calculatePIDParams();
        _autotuneStarted = false; // Stop autotuning
    }
}

bool AutotunePID::isRunning() {
    return _autotuneStarted;
}

void AutotunePID::getPIDParameters(float &Kp, float &Ki, float &Kd) {
    Kp = _Kp;
    Ki = _Ki;
    Kd = _Kd;
}

void AutotunePID::setTemperatureReadFunction(float (*tempReadFunc)()) {
    _tempReadFunc = tempReadFunc;
}

void AutotunePID::toggleHeater() {
    if (millis() - _lastSwitchTime > _switchDelay) {
        _heaterState = !_heaterState;
        digitalWrite(_heaterPin, _heaterState ? HIGH : LOW);
        //ledcWrite(_heaterPin, _heaterState ? 255 : 0);
        _lastSwitchTime = millis();
    }
}

void AutotunePID::recordPeak(float currentTemp) {
    if ((_lookingForMax && currentTemp < _lastTemp) || (!_lookingForMax && currentTemp > _lastTemp)) {
        if (_lookingForMax) _maxTemp = _lastTemp; else _minTemp = _lastTemp;
    
        unsigned long now = millis();
        if (_lastPeakTime != 0) { // Ignorer første peak
            unsigned long period = now - _lastPeakTime;
            _periodSum += period;
            _peakCount++;
        }
        _lastPeakTime = now;
        _lookingForMax = !_lookingForMax;
    }
    _lastTemp = currentTemp;
}

void AutotunePID::calculatePIDParams() {
    if (_peakCount < 2) return; // Sikrer, at vi har nok data til at beregne

    float amplitude = (_maxTemp - _minTemp) / 2.0;
    float averagePeriod = _periodSum / ((_peakCount - 1) / 2.0);

    float Ku = 4.0 * (1.0 / (PI * amplitude));
    float Tu = averagePeriod / 1000.0;

    _Kp = 0.6 * Ku;
    _Ki = 2 * _Kp / Tu;
    _Kd = _Kp * Tu / 8;

    Serial.print("Ku: "); Serial.println(Ku);
    Serial.print("Tu: "); Serial.println(Tu);
    Serial.print("Kp: "); Serial.println(_Kp);
    Serial.print("Ki: "); Serial.println(_Ki);
    Serial.print("Kd: "); Serial.println(_Kd);
}

double AutotunePID::readTemperature() {
    if (_tempReadFunc != nullptr) {
        return _tempReadFunc();
    } else {
        // Ingen indbygget temperatur-læsningsmetode tilgængelig; returner en fejl eller standardværdi.
        Serial.println("Error: No temperature read function defined.");
        return 0.0; // Return a default value or handle the error as appropriate.
    }
}

